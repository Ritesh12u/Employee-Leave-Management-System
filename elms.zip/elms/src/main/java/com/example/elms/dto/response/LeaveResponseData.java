package com.example.elms.dto.response;

import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder
public class LeaveResponseData {
    private Integer totalLeaves;
    private Integer RemainingLeaves;
    List<LeaveResponse> leaves;
}
