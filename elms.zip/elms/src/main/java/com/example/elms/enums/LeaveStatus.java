package com.example.elms.enums;

public enum LeaveStatus {
    PENDING,
    APPROVED,
    REJECTED
}
