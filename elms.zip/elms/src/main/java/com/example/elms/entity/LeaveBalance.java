package com.example.elms.entity;

import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity
@Table(name = "leave_balances")
public class LeaveBalance {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private int totalLeaves = 20;
    private int remainingLeaves = 20;

    @OneToOne
    @JoinColumn(name = "employee_id", unique = true)
    private Employee employee;

    public LeaveBalance() {}

    public LeaveBalance(Employee employee, int totalLeaves) {
        this.employee = employee;
        this.totalLeaves = totalLeaves;
        this.remainingLeaves = totalLeaves;
    }
}
