package com.example.elms.dto.request;

import lombok.Data;

import java.time.LocalDate;

@Data
public class LeaveRequestDTO {
    private LocalDate startDate;
    private LocalDate endDate;
    private String reason;
}
