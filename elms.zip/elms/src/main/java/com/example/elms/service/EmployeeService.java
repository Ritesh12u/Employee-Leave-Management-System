package com.example.elms.service;

import com.example.elms.dto.request.UpdateRoleRequest;
import com.example.elms.entity.Employee;
import com.example.elms.enums.Role;
import com.example.elms.repository.EmployeeRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class EmployeeService {
    private final EmployeeRepository employeeRepository;

    public List<Employee> getAllEmployee(){
        return employeeRepository.findAll();
    }

    public Employee updateRole(UpdateRoleRequest updateRoleRequest) {
        Employee employee = employeeRepository.findById(updateRoleRequest.getId()).get();
        employee.setRole(Role.valueOf(updateRoleRequest.getRole()));
        return employeeRepository.save(employee);
    }

    public Employee findByUserName(String name){
        return employeeRepository.findByEmail(name).orElse(null);
    }
}
