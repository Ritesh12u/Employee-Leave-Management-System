package com.example.elms.controller;

import com.example.elms.dto.request.LeaveRequestDTO;
import com.example.elms.dto.response.ApiResponse;
import com.example.elms.dto.response.LeaveResponse;
import com.example.elms.dto.response.LeaveResponseData;
import com.example.elms.entity.LeaveRequest;
import com.example.elms.service.LeaveService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/leaves")
public class LeaveController {

    private final LeaveService leaveService;

    public LeaveController(LeaveService leaveService) {
        this.leaveService = leaveService;
    }

    @PostMapping("/apply")
    public ResponseEntity<ApiResponse<String>> applyLeave(
            @RequestBody LeaveRequestDTO request,
            @AuthenticationPrincipal UserDetails user) {

        LeaveRequest leaveRequest = leaveService.applyLeave(user.getUsername(), request);

        return ResponseEntity.ok(
                new ApiResponse<>(
                        true,
                        "Leave applied successfully",
                        leaveRequest.getStatus().name()
                )
        );
    }

    @GetMapping("/my")
    public ResponseEntity<ApiResponse<LeaveResponseData>> getMyLeaves(
            @AuthenticationPrincipal UserDetails user) {

        List<LeaveResponse> leaves =
                leaveService.getMyLeaves(user.getUsername());

        return ResponseEntity.ok(
                new ApiResponse<>(
                        true,
                        "Leave history fetched",
                        LeaveResponseData.builder()
                                .totalLeaves(20)
                                .RemainingLeaves(leaveService.getRemainingLeaves(user.getUsername()))
                                .leaves(leaves)
                                .build()
                )
        );
    }
    
}
