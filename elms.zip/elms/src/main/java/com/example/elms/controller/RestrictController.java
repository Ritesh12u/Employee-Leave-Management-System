package com.example.elms.controller;

import com.example.elms.entity.Employee;
import com.example.elms.entity.LeaveRequest;
import com.example.elms.enums.Role;
import com.example.elms.service.EmployeeService;
import com.example.elms.service.LeaveService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@RequestMapping("/api/restrict/")
@RequiredArgsConstructor
public class RestrictController {
    private final LeaveService leaveService;
    private final EmployeeService employeeService;

    @GetMapping("/apply-list")
    public ResponseEntity<List<LeaveRequest>> applyList(@AuthenticationPrincipal UserDetails user){
        return ResponseEntity.ok(leaveService.getAllLeave());
    }

    @PostMapping("/approve/{id}")
    public ResponseEntity<LeaveRequest> approve(@AuthenticationPrincipal UserDetails user, @RequestParam String action,  @PathVariable Long id){
        validateAccess(user);
        return ResponseEntity.ok(leaveService.approveLeave(user.getUsername(), action, id));
    }

    private void validateAccess(UserDetails user) {
        String username = user.getUsername();
        Employee employee = employeeService.findByUserName(username);

        if (employee == null) {
            throw new AccessDeniedException("Unauthorized user");
        }

        if (employee.getRole() != Role.ADMIN && employee.getRole() != Role.MANAGER) {
            throw new AccessDeniedException("Link is restricted");
        }
    }


}
