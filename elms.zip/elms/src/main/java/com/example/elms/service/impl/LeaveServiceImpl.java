package com.example.elms.service.impl;

import com.example.elms.dto.request.LeaveRequestDTO;
import com.example.elms.dto.response.LeaveResponse;
import com.example.elms.entity.Employee;
import com.example.elms.entity.LeaveBalance;
import com.example.elms.entity.LeaveRequest;
import com.example.elms.enums.LeaveStatus;
import com.example.elms.exception.BadRequestException;
import com.example.elms.exception.InsufficientLeaveException;
import com.example.elms.exception.ResourceNotFoundException;
import com.example.elms.repository.EmployeeRepository;
import com.example.elms.repository.LeaveBalanceRepository;
import com.example.elms.repository.LeaveRequestRepository;
import com.example.elms.service.LeaveService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class LeaveServiceImpl implements LeaveService {

    private final EmployeeRepository employeeRepository;
    private final LeaveBalanceRepository leaveBalanceRepository;
    private final LeaveRequestRepository leaveRequestRepository;

    public LeaveServiceImpl(EmployeeRepository employeeRepository,
                            LeaveBalanceRepository leaveBalanceRepository,
                            LeaveRequestRepository leaveRequestRepository) {
        this.employeeRepository = employeeRepository;
        this.leaveBalanceRepository = leaveBalanceRepository;
        this.leaveRequestRepository = leaveRequestRepository;

    }

    @Override
    @Transactional
    public LeaveRequest applyLeave(String employeeEmail, LeaveRequestDTO request) {
        System.out.println(employeeEmail);
        Employee employee = employeeRepository.findByEmail(employeeEmail)
                .orElseThrow(() -> new ResourceNotFoundException("Employee not found"));

        LeaveBalance balance = leaveBalanceRepository.findByEmployeeId(employee.getId())
                .orElse(null);

        if (balance == null) {
            balance = leaveBalanceRepository.save(new LeaveBalance(employee, 20));
        }


        int totalDays = (int) ChronoUnit.DAYS.between(
                request.getStartDate(),
                request.getEndDate()
        ) + 1;

        if (totalDays <= 0) {
            throw new BadRequestException("Invalid leave dates");
        }

        if (balance.getRemainingLeaves() == 0 || balance.getRemainingLeaves() < totalDays) {
            throw new InsufficientLeaveException("Insufficient leave balance");
        }

        LeaveRequest leaveRequest = new LeaveRequest(
                employee,
                request.getStartDate(),
                request.getEndDate(),
                totalDays
        );

        leaveRequest.setLeaveReason(request.getReason());
        leaveRequest.setStatus(LeaveStatus.PENDING);

        leaveRequestRepository.save(leaveRequest);
        return leaveRequest;
    }

    @Override
    public List<LeaveResponse> getMyLeaves(String employeeEmail) {

        Employee employee = employeeRepository.findByEmail(employeeEmail)
                .orElseThrow(() ->
                        new ResourceNotFoundException("Employee not found"));

        return leaveRequestRepository.findByEmployee(employee)
                .stream()
                .map(lr -> new LeaveResponse(
                        lr.getStartDate(),
                        lr.getEndDate(),
                        lr.getTotalDays(),
                        lr.getStatus()
                ))
                .collect(Collectors.toList());
    }

    @Override
    public List<LeaveRequest> getAllLeave() {
        return leaveRequestRepository.findAll();
    }

    @Override
    public LeaveRequest approveLeave(String username, String action, Long id) {
        Employee employee = employeeRepository.findByEmail(username).get();
        LeaveRequest leaveRequest = leaveRequestRepository.findById(id).get();
        if(leaveRequest.getEmployee().getEmail().equals(employee.getEmail())) {
            throw new RuntimeException("You can't take any action in your own leave request");
        }
        leaveRequest.setStatus(LeaveStatus.valueOf(action));

        if(leaveRequest.getStatus() == LeaveStatus.APPROVED) {
            LeaveBalance balance = leaveBalanceRepository.findByEmployeeId(leaveRequest.getEmployee().getId())
                    .orElseThrow(() -> new RuntimeException("Leave balance not found"));
            balance.setRemainingLeaves(balance.getRemainingLeaves() - leaveRequest.getTotalDays());
            leaveBalanceRepository.save(balance);
        }
        return leaveRequestRepository.save(leaveRequest);
    }

    @Override
    public Integer getRemainingLeaves(String employeeEmail) {
        Employee employee = employeeRepository.findByEmail(employeeEmail).get();
        return leaveBalanceRepository.findByEmployeeId(employee.getId()).get().getRemainingLeaves();
    }

}
