package com.example.elms.enums;

public enum Role {
    EMPLOYEE,
    MANAGER,
    ADMIN
}
