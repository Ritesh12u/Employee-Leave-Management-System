package com.example.elms.entity;

import com.example.elms.enums.Role;
import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity
@Table(name = "employees")
public class Employee {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true)
    private String email;

    private String password;

    @Enumerated(EnumType.STRING)
    private Role role;

    public Employee() {}

    public Employee(String email, String password, Role role) {
        this.email = email;
        this.password = password;
        this.role = role;
    }
}
