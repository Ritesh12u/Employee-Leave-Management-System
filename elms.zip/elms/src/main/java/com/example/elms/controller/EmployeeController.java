package com.example.elms.controller;

import com.example.elms.dto.request.UpdateRoleRequest;
import com.example.elms.entity.Employee;
import com.example.elms.service.EmployeeService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/employee")
@RequiredArgsConstructor
public class EmployeeController {
    private final EmployeeService employeeService;

    @GetMapping
    public ResponseEntity<List<Employee>> get(){
        return ResponseEntity.ok(employeeService.getAllEmployee());
    }

    @PostMapping("promote")
    public ResponseEntity<Employee> updateRole(@RequestBody UpdateRoleRequest updateRoleRequest){
        return ResponseEntity.ok(employeeService.updateRole(updateRoleRequest));
    }
}
