package com.example.elms.entity;

import com.example.elms.enums.LeaveStatus;
import jakarta.persistence.*;
import lombok.Data;
import net.minidev.json.annotate.JsonIgnore;

import java.time.LocalDate;

@Data
@Entity
@Table(name = "leave_requests")
public class LeaveRequest {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private LocalDate startDate;
    private LocalDate endDate;
    private int totalDays;

    private String leaveReason;


    @Enumerated(EnumType.STRING)
    private LeaveStatus status;

    @JsonIgnore
    @ManyToOne
    @JoinColumn(name = "employee_id")
    private Employee employee;

    public LeaveRequest(Employee employee, LocalDate startDate, LocalDate endDate, int totalDays) {
        this.employee = employee;
        this.startDate = startDate;
        this.endDate = endDate;
        this.totalDays = totalDays;
    }

    public LeaveRequest() {

    }
}

