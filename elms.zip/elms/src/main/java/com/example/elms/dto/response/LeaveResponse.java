package com.example.elms.dto.response;

import com.example.elms.enums.LeaveStatus;

import java.time.LocalDate;

public class LeaveResponse {

    private LocalDate startDate;
    private LocalDate endDate;
    private int totalDays;
    private LeaveStatus status;

    public LeaveResponse(LocalDate startDate, LocalDate endDate,
                         int totalDays, LeaveStatus status) {
        this.startDate = startDate;
        this.endDate = endDate;
        this.totalDays = totalDays;
        this.status = status;
    }

    public LeaveStatus getStatus() {
        return status;
    }
}
