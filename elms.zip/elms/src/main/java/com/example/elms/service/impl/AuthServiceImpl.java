package com.example.elms.service.impl;

import com.example.elms.dto.request.LoginRequest;
import com.example.elms.dto.request.SignupRequest;
import com.example.elms.dto.response.JwtResponse;
import com.example.elms.entity.Employee;
import com.example.elms.entity.LeaveBalance;
import com.example.elms.enums.Role;
import com.example.elms.exception.BadRequestException;
import com.example.elms.repository.EmployeeRepository;
import com.example.elms.repository.LeaveBalanceRepository;
import com.example.elms.security.JwtUtils;
import com.example.elms.service.AuthService;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class AuthServiceImpl implements AuthService {

    private final EmployeeRepository employeeRepository;
    private final LeaveBalanceRepository leaveBalanceRepository;
    private final PasswordEncoder passwordEncoder;
    private final AuthenticationManager authenticationManager;
    private final JwtUtils jwtUtils;

    public AuthServiceImpl(EmployeeRepository employeeRepository,
                           LeaveBalanceRepository leaveBalanceRepository,
                           PasswordEncoder passwordEncoder,
                           AuthenticationManager authenticationManager,
                           JwtUtils jwtUtils) {
        this.employeeRepository = employeeRepository;
        this.leaveBalanceRepository = leaveBalanceRepository;
        this.passwordEncoder = passwordEncoder;
        this.authenticationManager = authenticationManager;
        this.jwtUtils = jwtUtils;
    }

    @Override
    public void signup(SignupRequest request) {

        if (employeeRepository.existsByEmail(request.getEmail())) {
            throw new BadRequestException("Email already registered");

        }

        Employee employee = new Employee(
                request.getEmail(),
                passwordEncoder.encode(request.getPassword()),
                Role.EMPLOYEE
        );

        employeeRepository.save(employee);

        // Default leave balance
        LeaveBalance leaveBalance = new LeaveBalance(employee, 20);
        leaveBalanceRepository.save(leaveBalance);
    }

    @Override
    public JwtResponse login(LoginRequest request) {

        authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(
                        request.getEmail(),
                        request.getPassword()
                )
        );

        String token = jwtUtils.generateToken(request.getEmail());
        return new JwtResponse(token);
    }
}
