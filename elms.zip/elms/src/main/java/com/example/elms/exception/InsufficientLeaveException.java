package com.example.elms.exception;

public class InsufficientLeaveException extends RuntimeException {

    public InsufficientLeaveException(String message) {
        super(message);
    }
}
