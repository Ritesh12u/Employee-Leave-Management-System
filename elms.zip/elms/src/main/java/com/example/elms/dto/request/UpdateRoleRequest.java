package com.example.elms.dto.request;

import lombok.Data;

@Data
public class UpdateRoleRequest {
    private Long id;
    private String role;
}
