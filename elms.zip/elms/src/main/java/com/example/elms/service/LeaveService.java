package com.example.elms.service;

import com.example.elms.dto.request.LeaveRequestDTO;
import com.example.elms.dto.response.LeaveResponse;
import com.example.elms.entity.LeaveRequest;

import java.util.List;

public interface LeaveService {

    LeaveRequest applyLeave(String employeeEmail, LeaveRequestDTO request);

    List<LeaveResponse> getMyLeaves(String employeeEmail);

    List<LeaveRequest> getAllLeave();

    LeaveRequest approveLeave(String username, String action, Long id);

    Integer getRemainingLeaves(String employeeEmail);
}
