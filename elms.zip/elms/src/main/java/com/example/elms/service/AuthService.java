package com.example.elms.service;

import com.example.elms.dto.request.LoginRequest;
import com.example.elms.dto.request.SignupRequest;
import com.example.elms.dto.response.JwtResponse;

public interface AuthService {

    JwtResponse login(LoginRequest request);

    void signup(SignupRequest request);
}
